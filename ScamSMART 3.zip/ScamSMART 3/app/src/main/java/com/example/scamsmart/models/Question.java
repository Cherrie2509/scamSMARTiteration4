package com.example.scamsmart.models;

import java.io.Serializable;

public class Question implements Serializable {

    //Model for questions to enable quizzes
    //code changed from this example https://www.geeksforgeeks.org/how-to-create-a-quiz-app-in-android/


    private int ID;
    private String imageurl;
    private String answer;
    private String category;
    private String explanation;

    public Question(String imageurl, String answer) {
        this.imageurl = imageurl;
        this.answer = answer;
    }

    public Question(int ID, String imageurl, String answer) {
        this.ID = ID;
        this.imageurl = imageurl;
        this.answer = answer;
    }

    public Question(String imageurl, String answer, String category) {
        this.ID = ID;
        this.imageurl = imageurl;
        this.answer = answer;
        this.category = category;
    }

    public Question(String imageurl, String answer, String category, String explanation) {
        this.imageurl = imageurl;
        this.answer = answer;
        this.category = category;
        this.explanation = explanation;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    @Override
    public String toString() {
        return "Question{" +
                "imageurl='" + imageurl + '\'' +
                ", answer='" + answer + '\'' +
                ", category='" + category + '\'' +
                ", explanation='" + explanation + '\'' +
                '}';
    }



}
