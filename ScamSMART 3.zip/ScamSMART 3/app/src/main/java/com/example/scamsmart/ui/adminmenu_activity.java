package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.scamsmart.R;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;

import org.jetbrains.annotations.NotNull;

public class adminmenu_activity extends AppCompatActivity {

    //Menu for admin. Currently only links to one activity


    Button btnPosts,btnEdit,btnSignOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminmenu);
        btnPosts = findViewById(R.id.btnGardaViewPosts);
        btnEdit = findViewById(R.id.btnViewStats);
        btnSignOut = findViewById(R.id.btnGardaOut);

        //Launches edit activity
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(adminmenu_activity.this,editcontent_activity.class);
                startActivity(intent);
            }
        });

        //Signs the admin out
        //https://stackoverflow.com/a/42571835
        btnSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AuthUI.getInstance()
                        .signOut(adminmenu_activity.this)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<Void> task) {
                                Intent intent = new Intent(adminmenu_activity.this,signin_activity.class);
                                startActivity(intent);
                                finish();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull @NotNull Exception e) {
                        Toast.makeText(adminmenu_activity.this, "Sign Out Failed", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });


        btnPosts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(adminmenu_activity.this,recent_firebase_activity.class);
                startActivity(intent);
            }
        });






    }
}