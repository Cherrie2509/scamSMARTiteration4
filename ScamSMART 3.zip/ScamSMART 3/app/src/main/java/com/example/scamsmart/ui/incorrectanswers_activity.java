package com.example.scamsmart.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.scamsmart.R;
import com.example.scamsmart.adapters.QuizRecyclerAdapter;
import com.example.scamsmart.models.Question;

import java.util.ArrayList;

public class incorrectanswers_activity extends AppCompatActivity {

    RecyclerView rvQuestions;
    RecyclerView.Adapter mAdapter;
    RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incorrectanswers_activity);

        rvQuestions = findViewById(R.id.rvQuiz);

        Intent intent = getIntent();
        Bundle args = intent.getBundleExtra("BUNDLE");
        ArrayList<Question> questionList = (ArrayList<Question>) args.getSerializable("ARRAYLIST");

        rvQuestions.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        rvQuestions.setLayoutManager(layoutManager);
        mAdapter = new QuizRecyclerAdapter(questionList,this);
        rvQuestions.setAdapter(mAdapter);

    }
}