package com.example.scamsmart.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.scamsmart.R;

public class instruction_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instruction_activity);
    }
}