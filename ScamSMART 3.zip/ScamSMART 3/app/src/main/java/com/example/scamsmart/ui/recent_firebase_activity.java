package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.scamsmart.R;
import com.example.scamsmart.adapters.PostAdapter;
import com.example.scamsmart.models.Post;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import org.jetbrains.annotations.NotNull;

public class recent_firebase_activity extends AppCompatActivity {


    //Displays the recent scams in a recycler view
    //https://codinginflow.com/tutorials/android/firebaseui-firestorerecycleradapter/part-3-firestorerecycleradapter

    //Declaration of firebase objects
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference postRef = db.collection("Posts");
    private PostAdapter adapter;
    FirebaseFirestore fStore;
    String userID;
    FirebaseAuth auth;
    String userType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_firebase);
        auth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        setupRecyclerview();
    }

    private void setupRecyclerview() {

        userID = auth.getCurrentUser().getUid();

        DocumentReference documentReference = fStore.collection("Users").document(userID);
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();

                    userType = String.valueOf(document.getData().get("type"));
                    Log.d("USERTYPE",userType);

                    //Sort the records retrieved
                    Query query = postRef.orderBy("timestamp", Query.Direction.DESCENDING);

                    //Declaring the recycler adapter and displaying it -
                    FirestoreRecyclerOptions<Post> options = new FirestoreRecyclerOptions.Builder<Post>()
                            .setQuery(query, Post.class)
                            .build();
                    adapter = new PostAdapter(options,recent_firebase_activity.this, userType);
                    RecyclerView recyclerView = findViewById(R.id.rvFBPosts);
                    recyclerView.setHasFixedSize(true);
                    recyclerView.setLayoutManager(new LinearLayoutManager(recent_firebase_activity.this));
                    recyclerView.setAdapter(adapter);
                    adapter.startListening();

                }
                else {
                    Toast.makeText(recent_firebase_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });


    }

    //This code is required in the onStart and onStop to ensure the recycler updates while the activity is active, and then stops updating when its not
    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}