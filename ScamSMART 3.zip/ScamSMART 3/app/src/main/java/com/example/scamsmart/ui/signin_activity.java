package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.scamsmart.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

public class signin_activity extends AppCompatActivity {



    //Allows the user to sign in
    //Adapted from https://github.com/bikashthapa01/firebase-authentication-android/blob/master/app/src/main/java/net/smallacademy/authenticatorapp/Login.java


    Button btnSignin, btnRegister;
    EditText etEmail, etPassword;
    FirebaseAuth auth;
    FirebaseFirestore fStore;
    String userID, isAdmin;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        auth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        //If the user is already signed in, send them to the main activity
        if(auth.getCurrentUser() != null) {

            userID = auth.getCurrentUser().getUid();

            Log.d("UID******",userID);
            DocumentReference documentReference = fStore.collection("Users").document(userID);
            documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();

                        isAdmin = String.valueOf(document.getData().get("type"));
                        Log.d("CHECKARRAY",isAdmin);
                        //This determines whether the user is sent to the regular section or the admin section
                        checkifAdmin(isAdmin);
                    }
                    else {
                        Toast.makeText(signin_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }

        btnSignin = findViewById(R.id.btnSignin);
        btnRegister = findViewById(R.id.btngotoRegister);
        etEmail = findViewById(R.id.etsigninemail);
        etPassword = findViewById(R.id.etsigninpassword);

        //Passes the email and password to firebase auth, which then determines if the details are correct
        btnSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                //Validation
                if(TextUtils.isEmpty(email)){
                    etEmail.setError("Email is Required.");
                    return;
                }

                if(TextUtils.isEmpty(password)){
                    etPassword.setError("Password is Required.");
                    return;
                }

                if(password.length() < 6){
                    etPassword.setError("Password Must be >= 6 Characters");
                    return;
                }

                auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            userID = auth.getCurrentUser().getUid();

                            Log.d("UID******",userID);
                            DocumentReference documentReference = fStore.collection("Users").document(userID);
                            documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();

                                        isAdmin = String.valueOf(document.getData().get("type"));
                                        Log.d("CHECKARRAY",isAdmin);
                                        //This determines whether the user is sent to the regular section or the admin section
                                        checkifAdmin(isAdmin);
                                    }
                                    else {
                                        Toast.makeText(signin_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });
                        }
                        else {
                            Toast.makeText(signin_activity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(signin_activity.this,register_activity.class);
                startActivity(intent);
            }
        });


    }
    
    public void checkifAdmin(String admin) {

        if(admin.equals("regular")) {
            Toast.makeText(signin_activity.this, "Signed In - Not Admin", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(signin_activity.this,MainActivity.class);
            startActivity(intent);
        }
        else if(admin.equals("admin")) {
            Toast.makeText(signin_activity.this, "Signed In - Admin", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(signin_activity.this,adminmenu_activity.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(signin_activity.this, "Signed In - Garda", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(signin_activity.this,gardamenu_activity.class);
            startActivity(intent);
        }
    }
}
