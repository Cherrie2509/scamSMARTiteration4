package com.example.scamsmart.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.example.scamsmart.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.jetbrains.annotations.NotNull;

public class textinfo_activity extends AppCompatActivity {

    FirebaseFirestore fStore;
    String article;
    TextView tvContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_textinfo_activity);

        fStore = FirebaseFirestore.getInstance();
        tvContent = findViewById(R.id.tvPhoneinfoContent);


        //Retrieving the document which contains the content for this activity
        DocumentReference documentReference = fStore.collection("InfoContent").document("TextScam");
        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    Log.d("DB*****",document.getData().get("Article") + "");
                    article = String.valueOf(document.getData().get("Article"));
                    Log.d("CHECKARRAY",article);
                    addtoArticle(article);
                }
                else {
                    Toast.makeText(textinfo_activity.this, "Nothing retrieved" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });

        //Make content scrollable, adapted from https://stackoverflow.com/questions/1748977/making-textview-scrollable-on-android
        tvContent.setMovementMethod(new ScrollingMovementMethod());
    }
    private void addtoArticle(String article) {
        tvContent.setText(article);
    }
}